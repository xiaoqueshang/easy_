// 准备封装 ajax

/*
  封装的步骤
    1. 判断参数是否符合要求
      1-1. 判断 url 是不是传递了
        + 如果你不传递 url 这个选项, 那么请求没有地方
        + 后面的代码就全都不需要执行了
      1-2. 判断请求方式
        + 判断你可以不传递, 但是只要你传递了, 你就要写 GET 或者 POST
        + 你不能写 abc
      1-3. 判断是否异步
        + 判断你可以不传递, 但是只要你传递了, 必须是一个 布尔值
        + 你不能写 abc
      1-4. 判断携带参数
        + 判断你可以不传递, 但是只要你传递了, 必须是一个符合规则的字符串
        + 'key=value&key2=value2'
      1-5. 判断是否解析
        + 判断你可以不传递, 但是只要你传递了, 必须是一个我规定的字符串
        + 你传递 'string' 表示不解析
        + 你传递 'json' 表示解析
        + 其他都不行
      1-6. 判断回调函数
        + 判断你可以不传递, 但是只要你传递了, 必须是一个函数数据类型
    2. 设置一个默认值
      + 准备一套默认值, 你没有传递的时候我就使用默认值
      + 你传递了, 用你传递的把我的默认值替换掉
    3. 根据我们的默认值去发送一个请求
      + 一套 ajax 的流程直接下来
      + 里面一些内容使用我们的默认值替换就行了
*/

function ajax(options) {
  // 1. 判断参数类型
  // 1-1. 判断 url 必填
  if (!options.url) throw new Error('url 为必填选项')

  // 1-2. 判断请求方式
  if (!(options.type === undefined || /^(get|post)$/i.test(options.type))) throw new Error('type 目前只接受 GET 和 POST 方式')

  // 1-3. 判断是否异步
  if (!(options.async === undefined || typeof(options.async) === 'boolean')) throw new Error('async 只能接受布尔值')

  // 1-4. 判断携带参数
  if (!(options.data === undefined || /^(.+=.+&{0,1})*$/.test(options.data))) throw new Error('data 必须符合 "key=value&key2=value2" 的数据格式')

  // 1-5. 判断是否解析
  if (!(options.dataType === undefined || /^(string|json)$/i.test(options.dataType))) throw new Error('dataType 目前只接受 string 和 json 参数')

  // 1-6. 判断回调函数
  if (!(options.success === undefined || typeof(options.success) === 'function')) throw new Error('success 必须是一个 function 数据类型')


  // 2. 准备一套默认值
  let _default = {
    url: options.url,
    type: options.type || 'GET',
    async: options.async === undefined ? true : options.async,
    data: options.data || '',
    dataType: options.dataType || 'string',
    success: options.success || function () { /* 一个默认值函数 */ }
  }

  // 3. 发送 ajax 请求
  // 3-1. 创建一个 ajax 对象
  let xhr = null
  if (XMLHttpRequest) {
    xhr = new XMLHttpRequest()
  } else {
    xhr = new ActiveXObject('Microsoft.XMLHTTP')
  }

  // 3-2. 配置请求信息
  if (/^get$/i.test(_default.type) && _default.data) {
    _default.url = _default.url + '?' + _default.data
  }
  xhr.open(_default.type, _default.url, _default.async)

  // 3-3. 先绑定事件
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && /^2\d{2}$/.test(xhr.status)) {
      if (_default.dataType === 'string') _default.success(xhr.responseText)

      if (_default.dataType === 'json') _default.success(JSON.parse(xhr.responseText))
    }
  }

  // 3-4. 发送请求
  if (/^post$/i.test(_default.type)) {
    xhr.setRequestHeader('content-type', 'application/x-www-form-urlencoded')
    xhr.send(_default.data)
  } else {
    xhr.send()
  }
}
