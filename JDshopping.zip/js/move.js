function move(ele, type, target, cb) {
  // cb 接受的就是你调用的时候传递的第四个参数, 是一个函数
  let speed = parseInt(getComputedStyle(ele)[type])
  let timerId = setInterval(() => {
    if (target > speed) {
      speed += 10
    } else {
      speed -= 10
    }
    ele.style[type] = speed + 'px'
    if (target > speed) {
      if (speed >= target) {
        clearInterval(timerId)
        cb()
      }
    } else {
      if (speed <= target) {
        clearInterval(timerId)
        cb()
      }
    }
  }, 10)
}
