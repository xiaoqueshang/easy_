/*
  1. 获取 form 标签, 取消默认事件
  2. 在表单提交事件里面要获取用户输入的内容
    + 用户名
    + 密码
    + 昵称
  3. 发送请求
  4. 根据后端的响应做对应的操作
*/

// 1. 获取元素
let form = document.querySelector('form')

// 2. 获取元素
let uname = document.querySelector('.username')
let upass = document.querySelector('.password')
let unick = document.querySelector('.nickname')
let errText = document.querySelector('form > span')

// 1-2. 绑定事件
form.addEventListener('submit', e => {
  // 1-3. 取消默认事件
  e = e || window.event
  e.preventDefault()

  // 2-2. 获取用户输入的内容
  let username = uname.value
  let password = upass.value
  let nickname = unick.value

  // 2-3. 非空验证
  if (username === '' || password === '' || nickname === '') {
    alert('请完整填写表单数据')
    return
  }

  // 3. 发送请求
  // 提前准备好参数字符串
  let dataStr = `username=${ username }&password=${ password }&nickname=${ nickname }`

  // 使用 ajax 方法
  ajax({
    url: '../server/register.php',
    type: 'POST',
    data: dataStr,
    dataType: 'json',
    success: function (res) {
      // res => 后端返回的数据
      // console.log(res)
      if (res.code === 1) {
       
        window.location.href = './login.html'
      } else {
   
        errText.className = 'active'
      }

    }
  })
})
