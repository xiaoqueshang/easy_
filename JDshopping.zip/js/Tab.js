// 1. 构造函数
function Tab(id, eventType = 'click') {
  // id 接受的就是 '#box' 这个字符串
  // 获取最大范围
  this.ele = document.querySelector(id)
  // 再整个文档流里面进行查找
  // this.btns = document.querySelectorAll('ul > li')
  // 再 this.ele(div#box) 里面查找 ul 下面的所有 li
  this.btns = this.ele.querySelectorAll('ul > li')
  this.tabs = this.ele.querySelectorAll('ol > li')

  this.type = eventType

  // 这里的 this 是谁 => 当前实例
  // 当前实例.change()
  this.change()
}
// 想 Tab 构造函数的原型上添加一个 change 方法
Tab.prototype.change = function () {
  let abc = this // 把 this 存储的地址复制了一份给了 abc 变量

  // 1. 给 btns 里面所有的 li 添加点击事件
  for (let i = 0; i < this.btns.length; i++) {
    // this.btns[i].setAttribute('index', i)
    this.btns[i].index = i
    this.btns[i].addEventListener(this.type, function () {
      // 2. 给 btns 里面的每一个 li 取消类名
      //    给 tabs 里面的每一个 li 取消类名
      // console.log(this) //=> 点击的那一个 li
      // console.log(abc) //=> 访问一个变量, 自己没有, 就去父级作用域查找
      // 因为 tabs 和 btns 都在 abc 里面呢
      for (let j = 0; j < abc.btns.length; j++) {
        abc.btns[j].className = ''
        abc.tabs[j].className = ''
      }

      // 3. 给你点击的这一个 li 添加 active
      this.className = 'active'
      //    给根 你点击的 li 索引配套的那一个 盒子添加 active
      // let index = this.getAttribute('index')
      // abc.tabs[index].className = 'active'
      abc.tabs[this.index].className = 'active'
    })
  }
}
