<?php

  # 1. 导入 base.php 文件
  include "./base.php";

  # 2. 接受前端发送来的数据
  $email = $_POST['email'];
  $info = $_POST['info'];
  $id = $_POST['userId'];

  # 3. 准备一个 sql 语句
  $sql = "UPDATE `users` SET `email`='$email', `info`='$info' WHERE `id`=$id";

  # 4. 执行 sql 语句
  mysql_query($sql);

  # 5. 返回修改成功
  $arr = array(
    "message" => "修改个人信息成功",
    "code" => 1
  );

  echo json_encode($arr);

?>
