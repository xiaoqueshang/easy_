<?php

  # 1. 导入 base.php 文件
  include "./base.php";

  # 2. 接受前端传递来的数据
  $oldPass = $_POST['oldPass'];
  $newPass = $_POST['newPass'];
  $id = $_POST['userId'];

  # 3. 先要根据 ID 和 旧密码查询一次数据库
  #    保证你给我的旧密码是对的
  $sql1 = "SELECT * FROM `users` WHERE `id`=$id AND `password`='$oldPass'";
  #    如果能查询出数据, 表示你给的旧密码是对的, 我就可以修改
  #    如果不能查询出数据, 表示你给的旧密码是错的, 旧不应该修改密码
  $res1 = mysql_query($sql1);
  $row1 = mysql_fetch_assoc($res1);
  # 通过条件判断决定要不要修改密码
  if (!$row1) {
    // 能进入 if 条件, 表示 !$row 是一个 true
    // 也就是 $row 自己是一个 false
    // $row === false 表示没有查询到数据, 表示你的旧密码不对
    $arr = array(
      "message" => "修改密码失败",
      "code" => 0
    );

    echo json_encode($arr);

    exit;
  }

  # 代码能执行到这里, 表示旧密码是对的
  # 4. 修改密码
  $sql2 = "UPDATE `users` SET `password`='$newPass' WHERE `id`=$id";
  mysql_query($sql2);

  $arr2 = array(
    "message" => "修改密码成功",
    "code" => 1
  );

  echo json_encode($arr2);

?>
